CodeMirror.fromTextArea(document.getElementsByTagName("textarea")[0], {
    lineNumbers: true,
    mode: 'htmlmixed'
});
