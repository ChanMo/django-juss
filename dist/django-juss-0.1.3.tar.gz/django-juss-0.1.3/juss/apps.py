from django.apps import AppConfig


class JussConfig(AppConfig):
    name = 'juss'
